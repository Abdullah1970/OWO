# Emoji package for GV4X Bot
